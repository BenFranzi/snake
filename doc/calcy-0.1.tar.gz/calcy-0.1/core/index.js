//renderer

//give access to main functions
const remote = require('electron').remote
const main = remote.require('./app.js')

var button = document.createElement('button')
button.textContent = 'Open a new window'
button.addEventListener('click', () => {
  main.openWindow()
}, false)
document.body.appendChild(button )
