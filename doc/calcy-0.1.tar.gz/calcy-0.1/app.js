//main process

const electron = require('electron')
const {app, BrowserWindow} = electron   //"pulls out" the app from the electron object

app.on('ready', ()=> {
  let win /*window*/ = new BrowserWindow({
    width: 800,
    height: 600
  })
  // win.loadURL('http://google.com')  //will load google
  win.loadURL(`file://${__dirname}/core/index.html`)
  win.webContents.openDevTools()
})


//for opening a new window
exports.openWindow = () => {
  let win = new BrowserWindow({
    width: 100,
    height: 600
  })
  win.loadURL(`file://${__dirname}/core/minor.html`)
}
