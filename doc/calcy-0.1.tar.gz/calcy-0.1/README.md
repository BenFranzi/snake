#Hello World
##The process of making this program

initialize project
>npm init

install electron dev dependencies
>npm i electron-prebuilt --save-dev

write boilerplate for the app.js
>const electron = require('electron')
const {app, BrowserWindow} = electron   //"pulls out" the app from the electron object

>app.on('ready', ()=> {
  let win = new BrowserWindow({
    width: 800,
    height: 600
  })
  win.loadURL(`file://${__dirname}/core/index.html`)
})

enable dev tools
>win.webContents.openDevTools()

give access to main for renderers
>const remote = require('electron').remote
const main = remote.require('./app.js')

package
>npm i electron-packager --save-dev

OSes
- win32
- darwin (macOS)
- mas (mac app store)
- linux
